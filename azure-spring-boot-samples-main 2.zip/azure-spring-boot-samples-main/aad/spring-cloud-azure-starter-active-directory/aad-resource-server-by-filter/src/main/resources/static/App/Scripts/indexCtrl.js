﻿'use strict';
angular.module('todoApp')
    .controller('indexCtrl', ['$scope', 'msalAuthenticationService', function ($scope, msalService) {

    }]);