﻿'use strict';
angular.module('todoApp')
    .controller('userDataCtrl', ['$scope', 'msalAuthenticationService', function ($scope, msalService) {


    }]);