---
page_type: sample
languages:
- java
products:
- azure-active-directory
name: Developing a Spring Bott Web Application Supports Login by Azure Active Directory Account via Certificate
description: This sample demonstrates how to develop a Spring Boot web application supports login by Azure Active Directory account via certificate.
---

# Developing a Spring Bott Web Application Supports Login by Azure Active Directory Account via Certificate

