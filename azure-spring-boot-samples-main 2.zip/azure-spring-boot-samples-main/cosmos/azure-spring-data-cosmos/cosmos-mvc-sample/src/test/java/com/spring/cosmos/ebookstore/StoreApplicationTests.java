package com.spring.cosmos.ebookstore;

import org.junit.jupiter.api.Test;

class StoreApplicationTests {
	@Test
	void contextLoads() {
	}
}
