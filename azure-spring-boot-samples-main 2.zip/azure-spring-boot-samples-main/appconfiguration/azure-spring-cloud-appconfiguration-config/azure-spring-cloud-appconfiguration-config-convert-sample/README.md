---
page_type: sample
languages:
- java
products:
- azure-app-configuration
name: Converting a Spring Boot Application With Cosmos Db to Be Using App Configuration and Key Vault
description: This sample demonstrates how to convert a Spring Boot application with Cosmos DB to be using App Configuration and Key Vault.
---

# Converting a Spring Boot Application With Cosmos Db to Be Using App Configuration and Key Vault

