#!/bin/bash

source ../keyvault-certificates-server-side/script/export_environment_variables.sh
source ../keyvault-certificates-server-side/script/export_environment_variables_of_created_resource.sh
