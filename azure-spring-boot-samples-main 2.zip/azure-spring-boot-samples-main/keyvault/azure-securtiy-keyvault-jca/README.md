---
page_type: sample
languages:
- java
products:
- azure-key-vault
name: Enabling HTTPS Connection by Certificate Stored in Azure Key Vault in Java Application
description: This sample demonstrates how to enable HTTPS connection by certificate stored in Azure Key Vault in Java application.
---

# Enabling HTTPS Connection by Certificate Stored in Azure Key Vault in Java Application

